var gulp = require("gulp");
var gulpPrefix = require("./gulp-prefixer.js");

gulp.src('./file.txt', { buffer: false })
.pipe(gulpPrefix('this is a prefixer ') )
.pipe(gulp.dest('test'));