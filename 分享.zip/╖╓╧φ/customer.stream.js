var stream = require( "stream" );
var util = require( "util" );
var Readable = stream.Readable;

util.inherits( customerReadable, Readable );





function customerReadable(data, opt){
	Readable.call(this, opt);
	this.data = data || [];
}

customerReadable.prototype._read = function(){
	var _this = this;
	this.data.forEach(function(d){
		_this.push(d);
	})
	this.push(null);
}

var data = ['aa', 'bb', 'cc'];
var r = new customerReadable(data);



r.on("data", function(chunk){
	//console.dir( r._readableState );
	console.log(chunk.toString());
})