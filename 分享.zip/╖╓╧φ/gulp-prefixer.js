var through = require('through2');

var gutil = require('gulp-util');

var Transform = require('readable-stream/transform');
var transform = Transform();

transform._transform = function( chunk, encoding, cb ){
    var tem = "two" + chunk.toString() + "one";
    cb(null ,  tem );
}

var pluginError = gutil.PluginError;

const PLUGIN_NAME = 'gulp-prefixer';

function prefixStream( prefixStream ){
    var stream = through();
    stream.write(prefixStream);
    console.dir( stream._readableState.buffer.toString() );
    return stream;
}

function gulpPrefixer(prefixText){
    if(!prefixText){
        throw new pluinError(PLUGIN_NAME, 'ǰ׺����Ϊ��');
    }

    prefixText = new Buffer(prefixText);

    var stream = through.obj(function(file, encoding, cb){

        //console.dir( file );

        if( file.isBuffer() ){
            this.emit("error", new pluginError(PLUGIN_NAME, "��֧�� Buffer ����"))
            return cb();
        }

        if( file.isStream() ){

            var streamer = prefixStream( prefixText );

            streamer.on("error", this.emit.bind(this, 'error') );

             file.contents.on("data", function(chunk, encode, cb){
                 //console.log( chunk.toString() );
                 //console.log( "go" );
                 //this.push.bind(this, streamer );
             });

            console.log("---");
            console.dir( file.contents._readableState.buffer.toString() );

            file.contents = file.contents.pipe(transform);

            console.log("--------------");
            console.dir( file.contents._readableState.buffer.toString() );

            //console.log( "\r" );

            //console.dir( file );
        }

        //this.push( file );

        cb(null, file);


    })

    return stream;


}

module.exports = gulpPrefixer;