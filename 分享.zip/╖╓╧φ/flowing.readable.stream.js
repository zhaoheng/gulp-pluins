// �¼�data��ʽ
var Read = require('stream').Readable;

var r = new Read();

r.push('hello ');
r.push('world!');
r.push(null);


r.pipe(process.stdout);

r.on('data', function (chunk) {
    //console.log('\r chunk :', chunk.toString() )
})
