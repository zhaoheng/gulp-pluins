var stream = require( "stream" );

var Readable = stream.Readable;

var rs = new Readable;

rs.push( 'beep ' );
rs.push( 'boop\n' );
rs.push( null );

rs.pipe(process.stdout);