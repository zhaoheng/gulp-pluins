import gulp from 'gulp';
import babel from 'gulp-babel';

const paths = {
  styles: {
    src: 'src/styles/**/*.less',
    dest: 'assets/styles/'
  },
  scripts: {
    src: 'src/scripts/**/*.js',
    dest: 'assets/scripts/'
  }
};

gulp.task('default', ()=>{
	console.log('default');
	
})
